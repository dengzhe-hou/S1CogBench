# S1CogBench homepage

This page uses a Leaderboard-First Nerfies design: a centered paper header, the overview, Table 3 as a full-width leaderboard, grey part bands, boxed figures, a BibTeX block and a plain footer.

`python scripts/build_homepage.py` copies `results/aggregate` to `homepage/data` and writes `homepage/docs` from `docs/`. It needs the `markdown` package. `--package` also rewrites the paper PDF and source archive in `homepage/downloads`; without it they stay as they are.

The leaderboard renders `data/table2.json`, which `scripts/build_table2.py` builds from the aggregate files. Bold and gray apply only among the five open models. There is no pooled cognitive score, no overall ranking and no rank column. Browser-local imports stay in the browser and are never uploaded.

The paper download is the current preprint. `.github/workflows/pages.yml` publishes this folder to GitHub Pages.
